
from urllib.request import urlopen
import json
import pyperclip
from discord_webhook import DiscordWebhook, DiscordEmbed

text = pyperclip.paste()

# DEFININDO URL
url = "https://economia.awesomeapi.com.br/last/USD-BRL"

# FAZENDO REQUEST E GUARDANDO A RESPOSTA
response = urlopen(url)

# GUARDANDO RESPOSTA USANDO JSON.LOADS
data_json = json.loads(response.read())

# DEFININDO VARIÁVEIS

# INICIANDO MONTAGEM DA MENSAGEM PARA ENVIAR PARA O DISCORD
webhook = DiscordWebhook(url='https://discord.com/api/webhooks/1006399575696867418/XA3DSVnyDV2XZexcfdq_SCGLxfBpDq6Qsx2qvy1nYd-OT8nHbUf5dCgLVvuBqFvPVmow')
embed = DiscordEmbed(title=text)

webhook.add_embed(embed)
response = webhook.execute(embed)